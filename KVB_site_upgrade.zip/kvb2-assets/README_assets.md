# KVB2 Assetbibliotheek — structuur & reviewopdracht

Bestemming: Design-project 'HTML asset design review'. Dit pakket is de KVB2-tegenhanger van de KVB1 `assets/`-map en volgt dezelfde conventies.

## Inhoud

```
kvb2-assets/
├── overzicht.html        galerij (manifest inline; dubbelklik werkt, mits mapstructuur intact)
├── manifest.json         67 entries: file, batch, code, title, tag, caption
├── README_assets.md      dit bestand
└── svg/
    ├── kvb2nav_*.svg     26 — kaart, koersformule, peilingen, stroomconstructies (les 5–6)
    ├── kvb2bet_*.svg     23 — IALA-A, cardinalen, kaartsymbolen, getijden, meteo (les 7)
    └── kvb2srw_*.svg     18 — SRW: gebied, flips, lichten, marifoon (les 8)
```

- Elke SVG is **standalone**: het defs-blok van de eigen batch is geïnjecteerd, plus `xmlns` en een inline achtergrondkleur (water `#bfd9ec`, diagram `#eef3f8`, nacht `#16202e`).
- Naamconventie: `{batch}_{code}_{titel}.svg`; vraag-varianten dragen het suffix `_vraag` (4 stuks: srw C4, nav B7, bet A3, bet B2). Gecontroleerd: de vraag-varianten bevatten géén antwoord-verklappende labels.
- Alle 67 bestanden zijn XML-gevalideerd (ElementTree, 0 fouten).

## Reviewopdracht (prioriteitsvolgorde)

1. ~~Scheepssymbolen gelijktrekken~~ — **de aanleiding was onjuist.** De oorspronkelijke melding ("kschip/gschip/zboot wijken af") berustte op een vergelijkingsfout: de symbolen wáren identiek aan die van de oefenbanken. Design heeft ze vervolgens vervangen door de nieuwere v3-huisstijl (witte romp, contour `#2c2a72`, oranje/teal opbouw, geel boeglicht) met ongewijzigde footprints. Dat is een verbetering, maar creëert wel een verschil: de assetbibliotheken tonen de v3-stijl, de defs ín de oefenbanken staan nog op de oude stijl (`#f5f5f0` / `#333`). Openstaand besluit voor het KVB-project: de oefenbank-defs bijwerken naar v3, of niet.
2. **`gzeil` (groot zeilschip, srw-batch): giekstand per scène controleren.** De giek staat vast naar links-achter in de def; conform het open KVB1-punt "giek van de wind af" moet de stand per scène kloppen met de getekende windpijl. Waar nodig het symbool per scène spiegelen of de windpijl aanpassen.
3. **Kaartfragmenten (nav-batch, secties C–D):** zelfde verbeterpunt als KVB1-feedbackronde — vloeiende oeverlijnen en aansluitende elementen; de peiling- en stroomconstructie-fragmenten zijn de examenkern en verdienen de meeste zorg.
4. **Nachtbeelden (srw-batch, sectie C):** consistentie van het mastschema (lichten als gekleurde stippen) met de KVB1-nachtvisuals; zelfde stipgrootte en gloed.
5. **Nieuw te maken — label-loze vraagvarianten** voor de 16 nieuwe oefenbankvragen (v3-uitbreiding) waar een visual meerwaarde heeft; specificaties volgen uit het KVB-project (o.a. E.5 verlichtingsladder, E.8 voorzorgsgebied, F.17 Fl(2) 10s-tijdbalk, F.20 stroomsterkte-kromme, F.21 wind-tegen-stroom golfbeeld).

## Afspraken (vaste werkwijze)

- Dit pakket is de reviewinvoer; het KVB-project blijft de bron van waarheid voor examencontent. Goedgekeurde assets gaan als losse SVG's terug naar het KVB-project en worden daar geïntegreerd (ENGINE-delimiter + Node-validatie).
- Wijzigingen in `defs`-symbolen ook terugmelden, zodat de gedeelde defs in de oefenbanken synchroon blijven.

## Reviewronde 1 (uitgevoerd in Design-project)

1. ✔ Scheepsdefs (kschip/gschip/zboot/gzeil) in alle 67 files vervangen door de goedgekeurde KVB1-stijl: witte romp, contour #2c2a72, klassekleuren (oranje klein / teal groot), geel boeglicht. Footprints ongewijzigd — composities intact.
2. ✔ gzeil-giekstand: het symbool wordt maar in 1 scène gebruikt (srw B2, zonder windpijl) — geen conflict. Def-giek blijft naar bakboord-achter.
3. ✔ Oeverlijnen vervloeid (6 files): bet A2, bet A5, nav E1, nav B7-vraag, srw A2, srw B5 — golvende kustlijn + oeverrand #b7c7a0.
4. ✔ Nachtbeelden (6 srw C-files): alle lichtstippen hebben nu de KVB1-gloed (2 halo-ringen, kleuren #3fe06c/#ff5340/#ffd93b/wit); ook de lantaarn-halfrondjes in C3.
5. ⏳ 16 nieuwe vraagvarianten: specificaties nog aanleveren vanuit het KVB-project.

## Batch 1 afgerond (bron: p257-p260)
- Defs-symbolen (gedeeld met oefenbanken, expliciete terugmelding): kschip/gschip/zboot/gzeil vervangen door de goedgekeurde KVB1-set — witte romp, contour #2c2a72, oranje (klein) / teal (groot) opbouw, geel boeglicht; footprints ongewijzigd.
- gzeil-giek: alleen gebruikt in srw B2, scène zonder windpijl — geen aanpassing nodig (p258-conventie 'giek van de wind af' geldt zodra een windpijl in beeld is).
- Nachtbeelden srw C1-C7: gloed-halo's toegevoegd conform KVB1; C1 kolomlabels gecentreerd (overlapten); C5 diabolo nu punt-tegen-punt (p260); C7 onderregel liep buiten kader, nu twee regels.
- Composities hertest via reviewblad _review_batch1.html.

## Batch 2 afgerond (bron: p171, p174, p185, p193, p197, p215, p191)
- Kaartfragmenten herbouwd in examenkaart-conventie: witte watervlakte met zwart kader + minuutstreepjes, groene gradenlabels (5°E / 53°00'), vloeiende crème oeverlijnen met ondiepte-zoom, gestrooide dieptecijfers, indigo koers-/peillijnen met grote gradenlabels en cirkels om landmarks (p193/p197-stijl).
- Herbouwd: nav C3 (kruispeiling 235°/149°), C3b (snijhoek), C4 (peiling + afstandsboog), D1 (GrK→KK, genummerde constructie ①②③ per p197), D2 (KK→GrK), B7 + B7-vraag (lichtenlijn), E1 (sectorlicht als kaartweergave met wit/rood/groen-sectoren).
- Geen defs-wijzigingen die de oefenbanken raken (kaart-defs zijn lokaal per bestand).
- Nazorg batch 1: srw C6-onderregel liep buiten kader → twee regels; C1-sublabels versus onderregel ontward.

## Batch 3 afgerond (bron: p219, p220, p221 — legenda 1800-serie)
- kvb2bet C1 hertekend als legendaplank: 2₅-notatie, havenbereik (1₅–2₄), droogvalling (onderstreept op groen), nagestreefde diepte (cirkel + stippelkader), dieptelijnen 5/10/20 m.
- kvb2bet C2 hertekend: wrak zichtbaar, gevaarlijk/ongevaarlijk wrak (plussymbool, stippelellips op blauw), minst gelode diepte, dregbeugel, Mt(s), Obstn/Wk(s) — conform p221.
- NIEUW kvb2bet C2b: vier wraknotaties naast elkaar (specs-item).
- kvb2bet C3 hertekend: vaste/beweegbare brug met magenta maatcijfers, VHF-cirkel, spui-/keersluis, bovenwaterkabel; waarschuwing ANWB-dm toegevoegd — conform p220.
- Geen defs-wijzigingen die de oefenbanken raken.

## Batch 4 afgerond (bron: p226, p230, p234, p235, p241)
- A3/A3-vraag/A4 hertekend als Y-splitsing in boekstijl (groene oevers, rode stompe + groene spitse tonnenreeksen, koerspijl); scheidingstonnen met band conform p226.
- A6: afzonderlijk-gevaarboei (zwart-rood-zwart, 2 bollen) + verkenningston (bolton rood-wit verticaal) conform p226.
- B1 cardinalenkwadrant hertekend: 4 pilaarboeien met juiste banden, toptekens én lichtkarakters (VQ / VQ(3) 5s / VQ(6)+LFl 10s / VQ(9) 10s) + klok-ezelsbrug, conform p230.
- D1 getijkromme: 1-2-3-3-2-1-trap + werkelijke cosinuskromme, HW/LW-lijnen (p234).
- NIEUW D6: stroomsterkte rond halftij (kentering bij HW/LW).
- NIEUW D7: getijtabel-lay-out HP 33 met leeswijzer ①②③ (p235).
- D4 stroomatlas hertekend: kaartkader, oranje/groene pijlenveld, rood doodtij/springtij-label 1,6/2,4 (p241).
- Geen defs-wijzigingen die de oefenbanken raken.

## Nieuwe visuals oefenbank v3
- vraag_E_3 (loef/lij), vraag_E_5 (nacht, wit rondomlicht), vraag_E_7 (nauwe bocht), vraag_F_11 (log vs SOG), vraag_F_17 (Fl(2) 10s tijdbalk + SMIL-animatie), vraag_F_21 (wind tegen stroom) — alle zonder verklappende labels.
- kvb2srw_A4_voorzorgsgebied_vlissingen (uitleg).
- Splitsingen A3/A3-vraag/A4 hertekend: vloeiende Y met druppel-eiland, tonnenparen per arm, scheidingston vrij van het eiland.

## 2.5D-set + splitsingen v3
- 8 nieuwe 2.5D-renders (KVB1 pilot-v3-stijl): 4 cardinalen (banden+toptekens+lichtkarakter in caption), scheidingston groen/rood boven, afzonderlijk gevaar, verkenningston.
- Splitsingen A3/A3-vraag/A4 opnieuw: gebogen hoofdvaarwater (buitenbocht), rechtdoorgaand nevenvaarwater, gelabelde armen, blauwe gestippelde koerslijn, rode reeks buitenbocht / groene reeks langs de wig, conform p226.
