# KVB Assetbibliotheek — structuur & upload

## Doelstructuur in de bestaande repo `KVB`

```
KVB/                          (bestaande repo — rg47y4msh5-prog/KVB)
├── index.html                (bestaand)
├── kvb1-oefenbank.html       (207 vragen, visuals inline)
├── kvb2-oefenbank.html       (108 vragen)
├── kvb2-visuals-*.html       (drie KVB2-bibliotheken)
├── kvb2-assets/              KVB2-assetbibliotheek (67 SVG's)
├── assets/                   ← NIEUW (deze map)
│   ├── overzicht.html        galerij van alle assets, met filter en zoek
│   ├── manifest.json         metadata per asset (code, titel, batch, tag)
│   ├── README_assets.md      dit bestand
│   └── svg/
│       ├── batch1_*.svg      24 stuks — vaarregels & situatieschetsen
│       ├── batch2_*.svg      17 stuks
│       ├── batch3_*.svg       9 stuks
│       └── vragen/
│           └── vraag_*.svg   22 stuks — visuals uit oefenbank v2 (slotcode in naam)
└── leeromgeving/             ← later, voor de les-dan-oefenen-modules
```

## Eenmalige upload (via github.com, geen git nodig)

1. Ga naar `github.com/rg47y4msh5-prog/KVB`
2. Klik **Add file → Upload files**
3. Sleep de complete map `assets/` in het venster (mapstructuur blijft behouden bij slepen van de map zelf)
4. Commit message: `Assets losgemaakt uit visualbibliotheken en oefenbank`
5. Na ± 1 minuut live op:
   `https://rg47y4msh5-prog.github.io/KVB/assets/overzicht.html`

## Naamconventie

`{bron}_{code}_{titel}.svg` — bijv. `batch1_A1_kruisende_koersen_uitleg.svg`
Vraagvisuals: `vraag_{slotcode}.svg` — bijv. `vraag_A_6.svg` (slot A.6, herkenbaar
in de oefenbank). Varianten krijgen `_v2`, `_v3`.

## Technische opzet

- Elke SVG is **standalone**: het gedeelde `<defs>`-blok (scheepssymbolen,
  pijlpunten, windroos) is in elk bestand geïnjecteerd, plus `xmlns`-attributen
  en een inline achtergrondkleur (water `#bfd9ec`, diagram `#eef3f8`,
  nachtvisuals `#101a2b`). Elk bestand opent dus correct in browser, editor
  (bijv. Inkscape / Boxy SVG) en als `<img src>`.
- `overzicht.html` heeft de manifest **inline** ingebed (geen fetch), zodat de
  galerij ook lokaal met dubbelklik werkt.

## Verbeterronde 1 (verwerkt, stijlbron: Studiewijzer 16e druk)

- **Schroefwater**: `vragen/vraag_D_9.svg` vervangen — golfjes i.p.v. pijlen
  (goedgekeurd voorbeeld). G4-sluis bevat alleen tekstlabels, geen tekening.
- **`betonning/` (14 nieuw, 2,5D-stijl p. 81–90)**: laterale stompe/spitse ton,
  drie scheidingstonnen, vier cardinalen, gele bijzondere markering,
  midvaarwaterton, afzonderlijk gevaar, twee havenpalen.
- **`borden/` (12 nieuw, officiële panelen p. 121–124 + bijlage 7 BPR)**:
  A.1, A.1a, A.12, A.13, A.15, A.17, B.9a, B.9b, B.11, E.10a, E.17, E.21.
  ⚠ E.10a is gereconstrueerd uit de vraagomschrijving ("blauw met wit kruis",
  dikke balk = kruisend hoofdvaarwater) — steekproef gewenst.

## Verbeterronde 2 (verwerkt)

- **`borden/` aangevuld tot volledige Bijlage 7-kern (54 nieuw)**: A.2–A.20
  (incl. A.5.1), B.1–B.11a, C.1–C.5, D.1a/b, D.3, E.1–E.24. Zelfde paneel-
  scaffold (paal, schaduw, code boven, omschrijving onder).
  ⚠ Gereconstrueerd zonder PDF-steekproef: B.8 (uitroepteken), A.10
  (begrenzingsbalken), B.2/B.4-pijlvormen — graag checken tegen p. 121–124.
- **`betonning/` aangevuld (11 nieuw)**: nachtversies met geanimeerd
  lichtkarakter (SMIL: flikker, Iso 4s, VQ, VQ(3)5s, VQ(6)+LFl 10s, VQ(9)10s,
  Fl(2)) voor laterale tonnen, vier cardinalen, midvaarwater, afzonderlijk
  gevaar en gele markering; plus kribbaken RO (rode kegel omlaag) en
  kribbaken LO (groene kegel omhoog).
- `manifest.json` + `overzicht.html` bijgewerkt (163 assets).

## Nog open uit feedbackronde 1

1. 2D-schepen verbeteren + 3D-versies (stijlbron: schippagina's uit de PDF).
2. Kaarten verbeteren (vloeiende oevers, aansluitende elementen).
3. Giekstand zeilboten herstellen (giek van de wind af).
4. Daarna: bestaande HTML's ombouwen naar `<img src="assets/svg/…">` en de
   leeromgeving in `/leeromgeving/` op dezelfde assets.


## Verbeterronde 3 (verwerkt in het KVB-project)

- `peilschaal/diepgang_waterdiepte.svg` — dubbel `x`-attribuut op een `<rect>` verwijderd (bestand parste niet).
- `schepen/klein_zeilboot_zij.svg` — dubbel `x2`-attribuut op een `<line>` verwijderd (idem).
- `betonning/_pilot_lateraal_spits_groen_v3.svg` staat op schijf maar niet in het manifest — bevestigen: archief of alsnog opnemen.
- De 22 vraagvisuals uit deze bibliotheek zijn inline geïntegreerd in `kvb1-oefenbank.html`; de oefenbank linkt niet naar deze map. Deze map is naslag/galerij.
- Nog te reviewen: 16 vraagvisuals die alleen in de 140-vragenlijn van de oefenbank bestonden en dus nooit door het Design-project zijn gezien (slots A.3, A.6, A.7, A.11, A.14, A.15, A.21, C.1, C.8, C.9, D.8).
